La página web se llama Bloc de Notas
Autor: David Cuesta Martínez
Repositorio Github:
https://github.com/DcM12345/Practica-1-Fundamentos-de-la-Web